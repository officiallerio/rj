import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [modalOpen, setModalOpen] = useState(false);
  const [venueModalOpen, setVenueModalOpen] = useState(false); // State for Venue Modal
  const [statusName, setStatusName] = useState('');
  const [venueName, setVenueName] = useState(''); // State for Venue Name
  const [statusList, setStatusList] = useState([]);
  const [venueList, setVenueList] = useState([]); // State for Venue List
  const [showList, setShowList] = useState(false);
  const [showVenueList, setShowVenueList] = useState(false); // State to control showing venue list

  // Fetch the list from the database for Status Availability
  const fetchStatusList = async () => {
    try {
      const response = await axios.get('http://localhost/gsd/api/add-status.php');
      setStatusList(response.data);
      setShowList(true); // Show the list after fetching
    } catch (error) {
      console.error('Error fetching status list:', error);
    }
  };

  // Fetch the list from the database for Venues
  const fetchVenueList = async () => {
    try {
      const response = await axios.get('http://localhost/gsd/api/add-venue.php'); // Assume a similar endpoint for venues
      setVenueList(response.data);
      setShowVenueList(true); // Show the list after fetching
    } catch (error) {
      console.error('Error fetching venue list:', error);
    }
  };

  // Submit the new status availability to the database
  const handleAddStatus = async () => {
    try {
      await axios.post('http://localhost/gsd/api/add-status.php', {
        status_availability_name: statusName,
      });
      setModalOpen(false);
      fetchStatusList(); // Fetch the updated list after adding new status
    } catch (error) {
      console.error('Error adding status availability:', error);
    }
  };

  // Submit the new venue to the database
  const handleAddVenue = async () => {
    try {
      await axios.post('http://localhost/gsd/api/add-venue.php', {
        venue_name: venueName,
      });
      setVenueModalOpen(false);
      fetchVenueList(); // Fetch the updated list after adding new venue
    } catch (error) {
      console.error('Error adding venue:', error);
    }
  };

  return (
    <div className="p-10 text-center bg-blue-50 min-h-screen">
      <h1 className="text-4xl font-bold text-blue-900 mb-10">Master Files</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Status Availability */}
        <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg shadow-lg transition-transform transform hover:scale-105">
          <h3 className="text-xl mb-4 font-semibold">Status Availability</h3>
          <button
            className="bg-blue-700 w-full py-2 mb-2 rounded-lg shadow hover:bg-blue-600 transition duration-200"
            onClick={() => setModalOpen(true)}
          >
            Add Availability
          </button>
          <button
            className="bg-blue-700 w-full py-2 rounded-lg shadow hover:bg-blue-600 transition duration-200"
            onClick={fetchStatusList}
          >
            Get List
          </button>
        </div>

        {/* Venue */}
        <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white p-6 rounded-lg shadow-lg transition-transform transform hover:scale-105">
          <h3 className="text-xl mb-4 font-semibold">Venue</h3>
          <button
            className="bg-blue-700 w-full py-2 mb-2 rounded-lg shadow hover:bg-blue-600 transition duration-200"
            onClick={() => setVenueModalOpen(true)} // Open Venue Modal
          >
            Add Venue
          </button>
          <button
            className="bg-blue-700 w-full py-2 rounded-lg shadow hover:bg-blue-600 transition duration-200"
            onClick={fetchVenueList} // Fetch venue list
          >
            Get List
          </button>
        </div>

      </div>

      {/* Modal for adding new status availability */}
      {modalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h2 className="text-xl mb-4 font-semibold">Add Status Availability</h2>
            <input
              type="text"
              className="border border-gray-300 p-2 mb-4 w-full text-black rounded focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter Status Name"
              value={statusName}
              onChange={(e) => setStatusName(e.target.value)}
            />
            <div className="flex justify-end">
              <button className="bg-red-500 text-white px-4 py-2 rounded-lg mr-2 hover:bg-red-400 transition duration-200" onClick={() => setModalOpen(false)}>
                Cancel
              </button>
              <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-400 transition duration-200" onClick={handleAddStatus}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal for adding new venue */}
      {venueModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h2 className="text-xl mb-4 font-semibold">Add Venue</h2>
            <input
              type="text"
              className="border border-gray-300 p-2 mb-4 w-full text-black rounded focus:outline-none focus:ring focus:ring-blue-500"
              placeholder="Enter Venue Name"
              value={venueName}
              onChange={(e) => setVenueName(e.target.value)}
            />
            <div className="flex justify-end">
              <button className="bg-red-500 text-white px-4 py-2 rounded-lg mr-2 hover:bg-red-400 transition duration-200" onClick={() => setVenueModalOpen(false)}>
                Cancel
              </button>
              <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-400 transition duration-200" onClick={handleAddVenue}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Display list of status availabilities */}
      {showList && (
        <div className="mt-10 bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl mb-4 font-semibold">Status Availability List</h2>
          <ul>
            {statusList.map((status) => (
              <li key={status.status_availability_id} className="mb-2 text-gray-700">
                {status.status_availability_name} (Admin ID: {status.status_availability_admin_id})
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Display list of venues */}
      {showVenueList && (
        <div className="mt-10 bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl mb-4 font-semibold">Venue List</h2>
          <ul>
            {venueList.map((venue) => (
              <li key={venue.venue_id} className="mb-2 text-gray-700">
                {venue.venue_name}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
