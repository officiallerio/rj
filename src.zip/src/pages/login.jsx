import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import secureSessionStorage from '../secureSessionStorage';
import { toast, ToastContainer } from 'react-toastify'; // Importing toast and ToastContainer
import 'react-toastify/dist/ReactToastify.css'; // Importing styles for toast notifications

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
            const url = "http://localhost/gsd/api/admin.php";
            const formData = new FormData();
            formData.append('operation', 'login');
            formData.append('json', JSON.stringify({ username, password }));
    
            const response = await axios.post(url, formData);

            console.log("response", response.data);
    
            if (response.data && response.data.admin_id && response.data.admin_level === 1) {
                secureSessionStorage.setItem('admin_id', response.data.admin_id);
                secureSessionStorage.setItem('admin_level', response.data.admin_level);
                secureSessionStorage.setItem('admin_name', response.data.admin_name);
                toast.success('Login successful! Redirecting to Dashboard...');
                navigate('/dashboard');
            } else if (response.data && response.data.cand_id) {
                navigate('/candidate-dashboard');
            } else if (response.data.error) {
                setErrorMessage(response.data.error); // Display server error message
            } else {
                setErrorMessage('Invalid username or password');
            }
        } catch (error) {
            console.error('Login failed:', error.response ? error.response.data : error);
            setErrorMessage('An error occurred during login.');
        }
    };
    

  return (
    
        <div className="h-screen flex items-center justify-center bg-gray-50">
          <div className="w-full max-w-sm m-auto bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-semibold text-center text-gray-800 mb-6">Welcome Back</h2>
            {errorMessage && <p className="text-red-500 text-center mb-4">{errorMessage}</p>}
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="username">
                  Username
                </label>
                <input
                  className="shadow-md appearance-none border border-gray-300 rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 text-sm font-medium mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  className="shadow-md appearance-none border border-gray-300 rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-between mb-4">
                <a className="text-sm text-blue-500 hover:text-blue-700 font-medium" href="#">
                  Forgot Password?
                </a>
              </div>
              <button
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150 ease-in-out"
                type="submit"
              >
                Sign In
              </button>
            </form>
            <p className="mt-4 text-center text-gray-600 text-sm">
              Don't have an account?{' '}
              <a className="text-blue-600 hover:text-blue-800 font-medium" href="#">
                Sign Up
              </a>
            </p>
          </div>
        </div>
  );
};

export default Login;
